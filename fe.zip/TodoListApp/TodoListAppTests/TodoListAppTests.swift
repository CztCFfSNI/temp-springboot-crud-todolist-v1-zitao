//
//  TodoListAppTests.swift
//  TodoListAppTests
//
//  Created by CztCFfSNI on 2025/8/29.
//

import Testing
@testable import TodoListApp

struct TodoListAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
