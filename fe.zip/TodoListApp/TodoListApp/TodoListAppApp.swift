import SwiftUI

@main
struct TodoListAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView() // 显示 ContentView 页面
        }
    }
}
