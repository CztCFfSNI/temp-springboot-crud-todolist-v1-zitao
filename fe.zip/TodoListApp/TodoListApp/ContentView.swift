// ContentView.swift
import SwiftUI

// ✅ 1. 数据模型
struct Task: Codable, Identifiable {
    let id: Int
    let title: String
    let description: String?
    let status: String
    let createdAt: String
    let userId: Int
}

// ✅ 2. 网络服务类
class TaskViewModel: ObservableObject {
    @Published var tasks: [Task] = []

    // 🔁 替换成你电脑的局域网 IP！
    private let baseURL = "http://192.168.0.100:8080/api/tasks"

    func fetchTasks() {
        guard let url = URL(string: baseURL) else { return }

        URLSession.shared.dataTask(with: url) { data, response, error in
            if let data = data {
                if let decodedTasks = try? JSONDecoder().decode([Task].self, from: data) {
                    DispatchQueue.main.async {
                        self.tasks = decodedTasks
                    }
                } else {
                    print("❌ 解码失败")
                }
            } else if let error = error {
                print("❌ 网络错误: \(error)")
            }
        }.resume()
    }
}

// ✅ 3. SwiftUI 视图
struct ContentView: View {
    @StateObject private var viewModel = TaskViewModel()

    var body: some View {
        NavigationView {
            List(viewModel.tasks) { task in
                VStack(alignment: .leading) {
                    Text(task.title)
                        .font(.headline)
                    if let desc = task.description, !desc.isEmpty {
                        Text(desc)
                            .font(.subheadline)
                            .foregroundColor(.gray)
                    }
                    HStack {
                        Text(task.status)
                            .font(.caption)
                            .padding(4)
                            .background(task.status == "COMPLETED" ? Color.green : Color.orange)
                            .foregroundColor(.white)
                            .cornerRadius(4)
                        Spacer()
                    }
                }
            }
            .navigationTitle("Todo List")
            .onAppear {
                viewModel.fetchTasks()
            }
            .refreshable {
                viewModel.fetchTasks()
            }
        }
    }
}

// ✅ 4. 预览（可选）
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
